package com.example.quadslvr

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.sqrt
import java.math.RoundingMode
import java.text.DecimalFormat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val solveIt = findViewById<Button>(R.id.solvebtn)
        solveIt.setOnClickListener {
            var sign1 = findViewById<EditText>(R.id.plusminus).text.toString().trim()
            val sign2 = findViewById<EditText>(R.id.plusminus1).text.toString().trim()
            val sign3 = findViewById<EditText>(R.id.plusminus2).text.toString().trim()
            try {
                var a = findViewById<EditText>(R.id.a).text.toString().trim().toDouble()
                var b = findViewById<EditText>(R.id.b).text.toString().trim().toDouble()
                var c = findViewById<EditText>(R.id.c).text.toString().trim().toDouble()
                //in this if condition whenever I use === or (.equals in java) it always evaluates to false and my logic doesn't work don't know why this happens
                if ((sign1 == "+" || sign1 == "-" || sign1 == "") && (sign2 == "+" || sign2 == "-") && (sign3 == "+" || sign3 == "-")) {
                    if (sign1 == "") {
                        sign1 = "+"
                        findViewById<EditText>(R.id.plusminus).setText("+")
                        //instead of this java method u can use .....(...plusminus)="+".toEditable() as EditText has editables
                    }
                    if (sign1 == "-")
                        a = -a
                    if (sign2 == "-")
                        b = -b
                    if (sign3 == "-")
                        c = -c
                    val d = b * b - 4 * a * c

                    val df = DecimalFormat("#.###")
                    df.roundingMode = RoundingMode.HALF_UP//half up is the type of rounding common people do
                    /*our formatter for decimal numbers. I could've used %.3f to get the same results but it was making even 2 to 2.000*/

                    if (d>0) {
                        val x1 = -(-b+sqrt(d))/2*a
                        val x2 =  ( b+sqrt(d))/2*a
                        var r1=df.format(x1)
                        var r2=df.format(x2)
                        r1= if(r1[0]!='-') "+ $r1" else "- "+r1.substring(1)
                        r2= if(r2[0]!='-') "+ $r2" else "- "+r2.substring(1)
                        Toast.makeText(this,"(x $r1)(x $r2) = 0",Toast.LENGTH_SHORT).show()
                    }
                    else if (d==0.0){
                        val x=-(-b + sqrt(d))/2*a
                        var r=df.format(x)
                        r = if(r[0]!='-') "+ $r" else "- "+r.substring(1)
                        Toast.makeText(this,"(x $r)² = 0",Toast.LENGTH_SHORT).show()
                    }
                    else{
                        //for non real roots
                        val x1 = -(-b+sqrt(-d))/2*a
                        val x2 =  ( b+sqrt(-d))/2*a
                        var r1=df.format(x1)+"i"
                        var r2=df.format(x2)+"i"
                        r1= if(r1[0]!='-') "+ $r1" else "- "+r1.substring(1)
                        r2= if(r2[0]!='-') "+ $r2" else "- "+r2.substring(1)
                        Toast.makeText(this,"(x $r1)(x $r2) = 0",Toast.LENGTH_SHORT).show()
                    }
                }
                else{
                    Toast.makeText(this, "Given Eqn was wrong !", Toast.LENGTH_SHORT).show()
                }
            } catch (e: NumberFormatException) {
                Toast.makeText(this, "Given Eqn was wrong !", Toast.LENGTH_SHORT).show()
            }
        }
        val reset=findViewById<Button>(R.id.reset)
        reset.setOnClickListener {
            findViewById<EditText>(R.id.plusminus).text.clear()
            findViewById<EditText>(R.id.plusminus1).text.clear()
            findViewById<EditText>(R.id.plusminus2).text.clear()
            findViewById<EditText>(R.id.a).text.clear()
            findViewById<EditText>(R.id.b).text.clear()
            findViewById<EditText>(R.id.c).text.clear()
        }
    }
}