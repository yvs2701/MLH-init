class Settings {
  bool sound;
  bool voice;

  Settings({
    this.sound,
    this.voice
  });
}